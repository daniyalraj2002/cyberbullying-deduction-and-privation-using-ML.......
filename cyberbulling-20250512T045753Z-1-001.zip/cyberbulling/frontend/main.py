
from flask_cors import CORS
from flask import *
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
app.config['SECRET_KEY'] = 'your_secret_key'
import sqlite3 
import os
import datetime
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = "uploads"  # Directory to save files
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)  # Create folder if not exists
from db import *
def connect():
#     return mysql.connector.connect(host="localhost", user="root",  password="",  database="chat",auth_plugin = 'mysql_native_password',port='3306')
        return sqlite3.connect("chat.db")

def predict_text(text):
    try:
        from keras.preprocessing.text import one_hot
        from keras.utils import pad_sequences
        import re
        from nltk.stem.snowball import SnowballStemmer
        from nltk.corpus import stopwords
        from tensorflow.keras.models import load_model
        import numpy as np

        # Load the saved model
        model = load_model("one.h5")
        # Text cleaning
        text_cleaning = "\b0\S*|\b[^A-Za-z0-9]+"

        stop_words = stopwords.words('english')

        def preprocess_filter(text, stem=False):
            text = re.sub(text_cleaning, " ", str(text.lower()).strip())
            tokens = []
            for token in text.split():
                if token not in stop_words:
                    if stem:
                        stemmer = SnowballStemmer(language='english')
                        token = stemmer.stem(token)
                    tokens.append(token)
            return " ".join(tokens)

        def one_hot_encoded(text, vocab_size=5000, max_length=40):
            hot_encoded = one_hot(text, vocab_size)
            return hot_encoded

            # word embedding pipeline

        def word_embedding(text):
            preprocessed_text = preprocess_filter(text)
            return one_hot_encoded(preprocessed_text)

        # Define the function for prediction input processing

        import torch
        from transformers import BertTokenizer, BertForSequenceClassification

        # Load model and tokenizer
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
        model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)  # Adjust labels
        model.load_state_dict(torch.load("modelBert1.pth", map_location=device))
        model.to(device)
        model.eval()

        # Example prediction
        text = "This is an example tweet."
        inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512).to(device)

        with torch.no_grad():
                outputs = model(**inputs)
                prediction = torch.argmax(outputs.logits, dim=1).item()

        print("Prediction:", prediction)
    except:
        pass


@app.route('/', strict_slashes=False)
def home():
    return render_template("index.html") 
@app.route('/chat/updatechat', methods=["POST"], strict_slashes=False)
def updatechat():
    r=request.json
    mydb = connect()
    d="update chat set senderid ='%s',receiverid ='%s',message ='%s',currentdata ='%s',filename ='%s',status ='%s' where cid='%s'"%(r['senderid'],r['receiverid'],r['message'],r['currentdata'],r['filename'],r['status'],r['cid'])
    mycursor = mydb.cursor()
    mycursor.execute(d)
    mydb.commit()
    mydb.close()
    return 's'
    
@app.route('/chat/viewchat', methods=["POST"], strict_slashes=False)
def viewchat():
        mydb = connect()
        mycursor = mydb.cursor()
        tx="select *   from chat"
        mycursor.execute(tx)
        e=mycursor.fetchall()
        mydb.close()
        return json.dumps(e)


@app.route('/chat/deletechat', methods=["POST"], strict_slashes=False)
def deletechat():
        r=request.json
        mydb = connect()
        mycursor = mydb.cursor()
        tx="delete from chat where cid={0}".format(r['id'])
        mycursor.execute(tx)
        mydb.commit()
        mydb.close()
        return 's'
@app.route('/insertusers', methods=["POST","GET"], strict_slashes=False)
def insertusers():
    if request.method=="POST":
        r=dict(request.form)
        r['designation']=""
        r['isapproved']="yes"
        mydb = connect()
        mycursor = mydb.cursor()
        tx = 'select uid from users order by uid desc limit 1'
        mycursor.execute(tx)
        e = mycursor.fetchall()
        if len(e) == 0:
                eid = 1
        else:
                eid = e[0][0]+1
        d="insert into users(uid,uname,email,mobile,Designation,password,isapproved)values ('%s','%s','%s','%s','%s','%s','%s')"%(eid,r['uname'],r['email'],r['mobile'],r['designation'],r['password'],r['isapproved'])
        mycursor = mydb.cursor()
        mycursor.execute(d)
        mydb.commit()
        mydb.close()
        return redirect("/")
    else:
          return render_template("reg.html")
    
@app.route('/chat/updateusers', methods=["POST"], strict_slashes=False)
def updateusers():
    r=request.json
    mydb = connect()
    d="update users set uname ='%s',email ='%s',mobile ='%s',role ='%s',password ='%s',isapproved ='%s' where uid='%s'"%(r['uname'],r['email'],r['mobile'],r['role'],r['password'],r['isapproved'],r['uid'])
    mycursor = mydb.cursor()
    mycursor.execute(d)
    mydb.commit()
    mydb.close()
    return 's'
@app.route('/chat/approveusers', methods=["POST"], strict_slashes=False)
def approveusers():
    r=request.json
    mydb = connect()
    d="update users set isapproved ='%s' where uid='%s'"%("yes",r['uid'])
    mycursor = mydb.cursor()
    mycursor.execute(d)
    mydb.commit()
    mydb.close()
    return 's'
    
@app.route('/chat/viewusers', methods=["POST"], strict_slashes=False)
def viewusers():
        mydb = connect()
        mycursor = mydb.cursor()
        tx="select *   from users"
        mycursor.execute(tx)
        e=mycursor.fetchall()
        mydb.close()
        return json.dumps(e)

@app.route('/chat/viewusersbyid', methods=["POST"], strict_slashes=False)
def viewusersbyid():
        r=request.json
        mydb = connect()
        mycursor = mydb.cursor()
        tx="select *   from users where uid!='%s'"%(r["id"])
        mycursor.execute(tx)
        e=mycursor.fetchall()
        mydb.close()
        return json.dumps(e)
@app.route('/chat/deleteusers', methods=["POST"], strict_slashes=False)
def deleteusers():
        r=request.json
        mydb = connect()
        mycursor = mydb.cursor()
        tx="delete from users where uid={0}".format(r['id'])
        mycursor.execute(tx)
        mydb.commit()
        mydb.close()
        return 's'

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)
def emoji(text):
    import emoji
    import re
    # Lowercase the text
    text = text.lower()
    # Demojify text
    text = emoji.demojize(text)
    # Remove URLs
    text = re.sub(r'http\S+', '', text)
    # Remove special characters
    text = re.sub(r'[^a-zA-Z0-9\s:]', '', text)
    return text
def textfromimage(input_image_path):
    import pytesseract
    from PIL import Image, ImageEnhance, ImageFilter

    # Path to Tesseract executable (Update this path if Tesseract is not in your system's PATH)
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'

    # Load the image
    
    processed_image_path = "temp2.png"

    # Open the image
    im = Image.open(input_image_path)

    # Preprocess the image
    # Apply a median filter to reduce noise
    im = im.filter(ImageFilter.MedianFilter())

    # Enhance contrast
    enhancer = ImageEnhance.Contrast(im)
    im = enhancer.enhance(2)  # Adjust the factor as needed

    # Convert to binary (black and white)
    im = im.convert('1')

    # Save the processed image for review
    im.save(processed_image_path)

    # Perform OCR on the processed image
    text = pytesseract.image_to_string(im, config='--psm 6')  # psm 6 assumes a single block of text

    return text
    
@app.route("/insertchat", methods=["POST"], strict_slashes=False)
def insertchat():
    now = datetime.datetime.now()
    r = dict(request.form)
    r["senderid"] = session["id"]
    r["message"]=emoji(r["message"])

    mydb = connect()
    mycursor = mydb.cursor()

    # Generate chat ID
    tx = "SELECT cid FROM chat ORDER BY cid DESC LIMIT 1"
    mycursor.execute(tx)
    e = mycursor.fetchall()
    eid = 1 if len(e) == 0 else e[0][0] + 1
    rx=0
    # Check if file is uploaded
    filename = ""
    if "file" in request.files:
        file = request.files["file"]
        if file.filename != "":
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)  # Save the file
            text=textfromimage(filepath)
            try:
                text=text.strip()
                if single_comment(text) == "s":
                    rx=1
            except:
                 pass

    print(rx)
    # Check for bullying words (Assuming `single_comment` handles this)
    if single_comment(r["message"]) == "s" or rx==1:
        block_query = """
            SELECT counts FROM chatblock WHERE 
            (touser='%s' AND fromuser='%s') OR (touser='%s' AND fromuser='%s')
        """%(r["senderid"], r["receiverid"], r["receiverid"], r["senderid"])
        mycursor.execute(block_query)
        rx = mycursor.fetchone()

        c = 1 if rx is None else rx[0] + 1
        if rx is None:
            block_insert = "INSERT INTO chatblock (fromuser, touser, ondate, counts) VALUES ('%s', '%s', '%s', '%s')"% (r["senderid"], r["receiverid"], now, c)
            mycursor.execute(block_insert)
        else:
            block_update = "UPDATE chatblock SET counts='%s', ondate='%s' WHERE fromuser='%s' AND touser='%s'"%(c, now, r["senderid"], r["receiverid"])
            mycursor.execute(block_update )

        mydb.commit()
        mydb.close()
        return "Contains Bully words"

    # Insert message into database
    chat_insert = """
        INSERT INTO chat (cid, senderid, receiverid, message, currentdata, filename, status) 
        VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')
    """%(eid, r["senderid"], r["receiverid"], r["message"], now, filename, r["status"])
    mycursor.execute(chat_insert)
    mydb.commit()
    mydb.close()

    return "Message Sent"
@app.route('/getchat', methods=["POST"], strict_slashes=False)
def getchat():
        r=request.form
        mydb = connect()
        mycursor = mydb.cursor()
        tx="select *   from chat  desc where senderid='%s' or receiverid='%s' and senderid='%s' or receiverid='%s' order by currentdata"%(r["toid"],r["toid"],session["id"],session["id"])
        mycursor.execute(tx)
        e=mycursor.fetchall()
        mydb = connect()
        mycursor = mydb.cursor()
        tx="select *   from chatblock where fromuser='%s' or touser='%s' and fromuser='%s' or touser='%s'"%(r["toid"],r["toid"],session["id"],session["id"])
        mycursor.execute(tx)
        ex=mycursor.fetchone()
        data={"chat":e,"block":ex}
        mydb.close()
        print(data)
        return json.dumps(data)
@app.route('/chatscreen', methods=["get"])
def chatscreen():
    mydb = connect()
    mycursor = mydb.cursor()
    tx="select *   from users where uid!='%s'"%(session["id"])
    mycursor.execute(tx)
    e=mycursor.fetchall()
    mydb.close()
    return render_template("chatscreen.html",e=e)


@app.route('/login', methods=["post","get"])
def login():
    if request.method=="POST":
        r = dict(request.form)
        con = connect()
        x="select uid,uname,isapproved from users where email='%s' and password='%s'"%(r["email"], r["password"])
        v = con.execute(x).fetchone()
        if v!=None:  
            session["id"]=v[0]
            session["name"]=v[1]
            return redirect("/chatscreen")
        else:
              return render_template("login.html",error="Unable to Login")
    return render_template("login.html")
if __name__ == '__main__':
        app.run("0.0.0.0") 